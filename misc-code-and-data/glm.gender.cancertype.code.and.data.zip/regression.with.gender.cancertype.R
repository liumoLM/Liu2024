
signature.assignment <- readRDS("./signature.assignment.df.rds") ##signature assignment result
metainfo <- readRDS("./metainfo.rds") ## meta info for PCAWG and HMF
## I only used the samples with reconstruction cos.sim > 0.9, so some samples don't have assignment result
metainfo <- metainfo[metainfo$new_sample_ID %in% colnames(signature.assignment),]

# remove 4 cancer types with strong gender bias
metainfo.temp <- metainfo[!metainfo$cancertype%in%c("Prostate","Uterus","Breast","Ovary"),]

gender.cancertype.OR <- {}


for(signature in row.names(signature.assignment)){
  
  
  metainfo.temp$sig.activity <- as.numeric(signature.assignment[signature,match(metainfo.temp$new_sample_ID,
                                                                     colnames(signature.assignment))])
  
 
  
  ## define signature presence. if activity>0, signature is present in the sample
  ## but this is not currently used in the later analysis
  metainfo.temp$signature.presence <- 0
  metainfo.temp$signature.presence[metainfo.temp$sig.activity>0]<-1
  
  ##logistic regression with gender and cancertype
  output <- glm(formula = as.factor(sig.activity) ~ factor(Gender) + factor(cancertype),
                data=metainfo.temp, family=binomial)
  
  
  coef.matrix <- as.data.frame(coef(summary(output)))
  coef.matrix <- coef.matrix[-1,]
  coef.matrix$temp <- row.names(coef.matrix)
  coef.matrix$Category <- apply(coef.matrix,1,function(x){
    unlist(strsplit(x["temp"],")"))[[2]]
  })
  coef.matrix$Signature <- signature
  gender.cancertype.OR <- rbind(gender.cancertype.OR,coef.matrix)
}
colnames(gender.cancertype.OR)[4] <- "p.value"
